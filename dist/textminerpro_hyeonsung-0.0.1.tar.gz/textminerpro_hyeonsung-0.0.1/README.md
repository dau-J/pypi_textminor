
# textminerpro

A Korean-friendly text preprocessing toolkit that supports:

- remove_stopwords(text, lang='en')
- extract_keywords(text, top_n=5)
- summarize_text(text, ratio=0.2)
- detect_language(text)
